﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Product p = new Product();
            try
            {
                Console.WriteLine("Enter the Product_Id");
                p.product_id = Convert.ToInt32(Console.ReadLine());
                if (p.product_id <= 0)
                {
                    var argumentException1 = new ArgumentException("Product Id must be greater than 0");
                    throw argumentException1;
                }
                Console.WriteLine("Enter the Product Name");
                p.product_name = Console.ReadLine();
                if (p.product_name == "")
                {
                    var argumentException2 = new ArgumentException("Product Name cannot be left blank");
                    throw argumentException2;
                }
                Console.WriteLine("Enter the Price of the Product");
                p.price = Convert.ToInt32(Console.ReadLine());
                if (p.price <= 0)
                {
                    var argumentException3 = new ArgumentException("Price of the Product must be greater than 0");
                    throw argumentException3;
                }
            }

            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                Console.WriteLine("Press any key to terminate");
                Console.ReadKey();
            }


        }
    }
}
