﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_new
{
    class Product
    {
       public int Id { get; set; }
       public String Name { get; set; }
       public Double Price { get; set; }
       public String Category { get; set; }
       public DateTime CreatedOn { get; set; }
        public Product(int id, string name, double price,string Category,DateTime createdOn)
        {
            this.Id = id;
            this.Name = name;
            this.Price = price;
            this.Category = Category;
            this.CreatedOn = createdOn;
            

        }
        public static List<Product> GetProducts()
        {

            var Product = new List<Product>()

            {
                new Product(101,"Pendrive",1100,"Electronics",new DateTime(2020,01,01)),
                new Product(102,"WirelessKeyboard",3000,"Electronics",new DateTime(2020,12,12)),
                new Product(103,"WirelessMouse",1500,"Electronics",new DateTime(2021,02,12)),
                new Product(104,"FormalShoes",3000,"Foot Wear",new DateTime(2021,01,10)),
                new Product(105,"FormalShirt",2200,"Clothing",new DateTime(2020,12,01))
                

            };
            return Product;
        }
        public override string ToString()
        {
            return this.Id+"\t"+this.Name+"\t"+this.Price+"\t"+this.Category+"\t"+this.CreatedOn;
        }
    }
}
