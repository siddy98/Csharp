﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_new
{
    class Program
    {
       
        static void Main(string[] args)
        {
            DateTime d = new DateTime(2020,12,31);
    
   
            var DataSource = Product.GetProducts();
            var result1 = from item in DataSource
                          orderby item.Name ascending
                          select item;

            Console.WriteLine("Displaying all items in Ascending order of their name");
            foreach (var r in result1)
            {
                Console.WriteLine(r);
            }

            var result2 = from item in DataSource
                          where item.Price>1000 && item.Price<2000 && item.Category=="Electronics"
                          orderby item.Id ascending
                          select item;
            Console.WriteLine();
            Console.WriteLine("Displaying all items in Electronics Category and price between 1000 and 2000");
            foreach (var r in result2)
            {
                Console.WriteLine(r);
            }
            var result3 = from item in DataSource
                          where DateTime.Compare(item.CreatedOn,d)>0
                          orderby item.Id ascending
                          select item;
            Console.WriteLine();
            Console.WriteLine("Displaying all items created in 2021");
            foreach (var r in result3)
            {
                Console.WriteLine(r);
            }
            Console.ReadKey();




        }
    }
}
