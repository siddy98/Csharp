﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program
    {
        class Calculator
        {
            public int Number1 { get; set; }
            public int Number2 { get; set; }
        }
        delegate void Calculateit(Calculator c);
        static void Main(string[] args)
        {
           
            var d = new Calculator();
            Console.WriteLine("Enter Number1: ");
            d.Number1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Number2: ");
            d.Number2 = Convert.ToInt32(Console.ReadLine());
            var cal = new Calculateit(Add);
            cal += Subtract;
            cal += Multiplication;
            cal += Division;
            if (cal != null)
            {
                cal(d);
            }
            Console.ReadKey();

        }
        static void Add(Calculator c)
        {
            Console.WriteLine("After Addition:{0}", c.Number1 + c.Number2);
        }

       static void Subtract(Calculator c)
        {
            Console.WriteLine("After Subtraction:{0}", c.Number1 - c.Number2);
        }

        static void Division(Calculator c)
        {
            Console.WriteLine("After Division:{0}", c.Number1 / c.Number2);
        }

        static void Multiplication(Calculator c)
        {
            Console.WriteLine("After Multiplication:{0}", c.Number1 * c.Number2);
        }





    }
  
}
