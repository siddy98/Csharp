﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignemnt3
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            int account_number;
            String customer_name;
            var d = new Dictionary<int, String>();
            do
            {
                Console.WriteLine("**********MENU**********");
                Console.WriteLine("1.Add");
                Console.WriteLine("2.Search");
                Console.WriteLine("3.Delete");
                Console.WriteLine("4.Display");
                Console.WriteLine(" Choice:");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {

                    case 1:
                        Console.WriteLine("Enter Account Number:");
                        account_number = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Customer Name:");
                        customer_name = Console.ReadLine();
                        d.Add(account_number, customer_name);
                        break;
                    case 2:
                        Console.WriteLine("Enter Account Number:");
                        account_number = Convert.ToInt32(Console.ReadLine());
                        if (d.ContainsKey(account_number))
                        {
                            Console.WriteLine("Found an entry for Account_Number:{0} with Customer Name: {1}", account_number, d[account_number]);
                        }
                        else
                        {
                            Console.WriteLine("Search not found!!");
                        }
                        break;

                    case 3:
                        Console.WriteLine("Enter Account Number to delete:");
                        account_number = Convert.ToInt32(Console.ReadLine());
                        d.Remove(account_number);
                        break;
                    case 4:
                        foreach (KeyValuePair<int, String> entry in d)
                            Console.WriteLine("{0} {1}",entry.Key,entry.Value);
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;




                }


            } while (1==1);
        }
    }
}
