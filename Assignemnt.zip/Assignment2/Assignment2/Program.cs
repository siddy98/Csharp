﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            String dcode;
            string district;
            int choice;
            var d = new Hashtable();
            do {
                Console.WriteLine("**********MENU**********");
                Console.WriteLine("1.Add RTO District");
                Console.WriteLine("2.Search an RTO District");
                Console.WriteLine("3.Display all RTO Districts");
                Console.WriteLine("4.Total Count");
                Console.WriteLine("5.Remove an RTO District");
                Console.WriteLine(" Choice:");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter District Code:");
                        dcode = Console.ReadLine();
                        Console.WriteLine("Enter District Name:");
                        district = Console.ReadLine();
                        d.Add(dcode, district);
                        break;
                    case 2:
                        Console.WriteLine("Enter District Code :");
                        dcode = Console.ReadLine();
                        if (d.ContainsKey(dcode))
                        {
                            Console.WriteLine("Found {0}", d[dcode]);
                        }
                        else
                        {
                            Console.WriteLine("Search not found!!!");
                        }
                        break;
                    case 3:
                        foreach (DictionaryEntry entry in d)
                        {
                            Console.WriteLine("{0} {1}", entry.Key, entry.Value);

                        }
                        break;
                    case 4:
                        Console.WriteLine("Total Count:{0}", d.Count);
                        break;
                    case 5:
                        Console.WriteLine("Enter the district code to delete: ");
                        dcode = Console.ReadLine();
                        d.Remove(dcode);
                        Console.WriteLine("District entry is removed!");
                        break;
                }
            } while (1==1);

           } 
    }
}
