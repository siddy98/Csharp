﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class Program
    {
        static void Main(string[] args)
        {

            int choice;
            int account_number;
            
            String contact_name;
            var d = new List<Contact>();
            do
            {
                Console.WriteLine("**********MENU**********");
                Console.WriteLine("1.Add");
                Console.WriteLine("2.Display");
                Console.WriteLine("3.Edit Contact");
                Console.WriteLine("4.Show All Contacts");
                Console.WriteLine(" Choice:");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {

                    case 1:
                        var obj = new Contact();
                        Console.WriteLine("Enter Contact Number:");
                        obj.contactNo = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Contact Name:");
                        obj.ContactName = Console.ReadLine();
                        Console.WriteLine("Enter Cell Number:");
                        obj.cellno = Console.ReadLine();
                        d.Add(obj);
                        break;
                    case 2:
                        Console.WriteLine("Enter the Contact Name: ");
                        contact_name = Console.ReadLine();
                        foreach(var ob in d)
                        {
                            if (ob.ContactName == contact_name)
                            {
                                Console.WriteLine("Contact Number:{0}  CellNumber:{1}", ob.contactNo, ob.cellno);
                            }
                        }
                        break;

                    case 3:
                        Console.WriteLine("Enter Contact Name to edit:");
                        contact_name = Console.ReadLine();
                        int flag = 0;
                        foreach(var b in d)
                        {
                            if (b.ContactName == contact_name)
                            {
                                Console.WriteLine("Enter New Contact Number:");
                                b.contactNo = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Enter Cell Number:");
                                b.cellno = Console.ReadLine();
                                flag = 0;
                            }
                            else
                            {
                                flag = 1;
                            }
                        }
                        if (flag == 1)
                        {
                            Console.WriteLine("There is no such contact!!");
                        }
                        break;
                    case 4:
                        Console.WriteLine("ContactNumber ContactName CellNumber");
                        foreach (var ob in d)
                        {
                            
                            Console.WriteLine("{0}           {1}          {2}", ob.contactNo, ob.ContactName, ob.cellno);
                        }
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;




                }


            } while (1 == 1);
        }
    }
}
