﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    public class Contact
    {
        public int contactNo { get; set;}
        public string ContactName { get; set; }
        public string cellno { get; set; }
    }
}
